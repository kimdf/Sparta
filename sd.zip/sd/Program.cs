﻿using System;
using System.Collections.Generic;

// 캐릭터 클래스 정의
class Character
{
    public int Level;
    public string Name;
    public string Job;
    public int BaseAttack;
    public int BaseDefense;
    public int HP;
    public int Gold;
    public int Age;
    public string Gender;
    public int TotalAttack;
    public int TotalDefense;

    public Character(string name, string job)
    {
        Level = 1;
        Name = name;
        Job = job;
        // 기본 스탯. 이후 아이템 장착시 보정됨.
        BaseAttack = new Random().Next(5, 11); // 5 ~ 10
        BaseDefense = new Random().Next(3, 8);  // 3 ~ 7
        HP = 100;
        Gold = new Random().Next(1000, 2000);
        Age = 20;
        Gender = "남성";
        UpdateTotalStats();
    }
    public void UpdateTotalStats()
    {
        TotalAttack = BaseAttack;
        TotalDefense = BaseDefense;
    }
}

// 아이템 클래스 정의
class Item
{
    public string Name;
    public string Type; // "공격력" 또는 "방어력"
    public int Bonus;
    public string Description;
    public bool Equipped;

    public Item(string name, string type, int bonus, string desc)
    {
        Name = name;
        Type = type;
        Bonus = bonus;
        Description = desc;
        Equipped = false;
    }
}

// 동료 클래스 정의 (마왕 동료)
class Companion
{
    public string Name;
    public int HP;
    public int MP;
    public string Equipment;
    public string Gender;
    public string Status;
    public string State;

    public Companion(string name)
    {
        Name = name;
        HP = 150;
        MP = 50;
        Equipment = "없음";
        Gender = "남성";
        Status = "동료";
        State = "정상";
    }
}

class Program
{
    static Character player;
    static List<Item> inventory = new List<Item>();
    static Companion companion = null;
    // 게임 진행 여부
    static bool gameOver = false;
    static bool secondPlay = false;
    static Random rand = new Random();

    static void Main(string[] args)
    {
        while (true)
        {
            Console.Clear();
            ShowSplashScreen(); // 스플래시 타이틀 및 직업, 이름 입력
            CreateCharacter();  // 캐릭터 생성 및 NPC 인사 메시지 출력

            // 초기 아이템 3개 추가
            inventory.Clear();
            inventory.Add(new Item("무쇠갑옷", "방어력", 5, "무쇠로 만들어져 튼튼한 갑옷입니다."));
            inventory.Add(new Item("낡은 검", "공격력", 2, "쉽게 볼 수 있는 낡은 검 입니다."));
            inventory.Add(new Item("연습용 창", "공격력", 3, "검보다는 그대로 창이 다루기 쉽죠."));

            // 두번째 플레이시 동료(마왕)를 추가
            if (secondPlay)
            {
                companion = new Companion("마왕");
            }
            else
            {
                companion = null;
            }

            // 메인 게임 루프
            while (!gameOver)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("스파르타 마을에 오신 여러분 환영합니다.");
                Console.WriteLine("이곳에서 던전으로 들어가기 전 활동을 할 수 있습니다.\n");
                Console.WriteLine("1. 상태 보기");
                Console.WriteLine("2. 인벤토리");
                Console.WriteLine("3. 던전 탐험");
                Console.WriteLine("4. 길드 생성");
                Console.WriteLine("0. 게임 종료");
                Console.Write("\n원하시는 행동을 입력해주세요.\n>> ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    ShowStatusView();
                }
                else if (input == "2")
                {
                    ShowInventory();
                }
                else if (input == "3")
                {
                    DungeonExplore();
                }
                else if (input == "4")
                {
                    CreateGuild();
                }
                else if (input == "0")
                {
                    gameOver = true;
                }
                else
                {
                    Console.WriteLine("- 잘못된 입력입니다");
                    Pause();
                }
            }

            // 게임 엔딩 - ASCII 아트 꽃 표시 및 재시작 물음
            Console.Clear();
            ShowEnding();
            Console.Write("\n게임을 다시 시작하시겠습니까? (y/n): ");
            string restart = Console.ReadLine().ToLower();
            if (restart != "y")
                break;
            else
            {
                // 두번째 플레이부터는 동료 마왕 등장
                secondPlay = true;
                gameOver = false;
            }
        }
    }

    // 스플래시 스크린과 직업/이름 선택, 무지개 색 텍스트 출력
    static void ShowSplashScreen()
    {
        string title = "스파르타 이세계 판타지";
        int windowWidth = Console.WindowWidth;
        int padLeft = (windowWidth - title.Length) / 2;
        // 무지개 색 (빨강, 노랑, 녹색, 청, 자, 흰)
        ConsoleColor[] rainbow = new ConsoleColor[] {
            ConsoleColor.Red, ConsoleColor.Yellow, ConsoleColor.Green,
            ConsoleColor.Cyan, ConsoleColor.Magenta, ConsoleColor.White
        };
        for (int i = 0; i < title.Length; i++)
        {
            Console.ForegroundColor = rainbow[i % rainbow.Length];
            Console.Write(title[i]);
        }
        Console.WriteLine("\n");
        Console.ResetColor();

        Console.Write("직업을 선택하세요 (마법사 / 전사 / 마창사 / 검사): ");
    }

    static void CreateCharacter()
    {
        string job = Console.ReadLine();
        if (job != "마법사" && job != "전사" && job != "마창사" && job != "검사")
        {
            job = "전사";
        }
        Console.Write("이름을 입력하세요: ");
        string name = Console.ReadLine();
        player = new Character(name, job);

        // NPC 인사
        Console.Clear();
        Console.WriteLine("왕: 어서오시게 용사여 마왕을 없애주게나 골치거리입니다");
        Console.WriteLine("공주: 당신의 모험을 응원하오니 부디 힘내시길...\n");
        Console.WriteLine("필살기: 즉사 (스킬 목록에 등록됨)");
        Pause();
    }

    // 상태보기 화면
    static void ShowStatusView()
    {
        Console.Clear();
        // 장착된 아이템 보너스 반영
        player.UpdateTotalStats();
        foreach (var it in inventory)
        {
            if (it.Equipped)
            {
                if (it.Type == "공격력")
                    player.TotalAttack += it.Bonus;
                else if (it.Type == "방어력")
                    player.TotalDefense += it.Bonus;
            }
        }
        Console.WriteLine($"Lv. {player.Level:00}");
        Console.WriteLine($"{player.Name} ({player.Job})");
        Console.WriteLine($"공격력 : {player.TotalAttack}");
        Console.WriteLine($"방어력 : {player.TotalDefense}");
        Console.WriteLine($"체력 : {player.HP}");
        Console.WriteLine($"Gold : {player.Gold} G");
        Console.WriteLine($"나이 : {player.Age}세, 성별 : {player.Gender}");
        if (companion != null)
        {
            Console.WriteLine($"\n동료 - {companion.Name} / HP: {companion.HP} / MP: {companion.MP} / 상태: {companion.State}");
        }
        Console.WriteLine("\n0. 나가기");
        Console.Write("\n원하시는 행동을 입력해주세요.\n>> ");
        string inp = Console.ReadLine();
        // 0 입력시 이전 메뉴로 복귀
    }

    // 인벤토리 화면
    static void ShowInventory()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("인벤토리");
            Console.WriteLine("[아이템 목록]");
            for (int i = 0; i < inventory.Count; i++)
            {
                string equipMark = inventory[i].Equipped ? "[E]" : "";
                Console.WriteLine($"- {i + 1} {equipMark}{inventory[i].Name} | {inventory[i].Type} +{inventory[i].Bonus} | {inventory[i].Description}");
            }
            Console.WriteLine("\n1. 장착관리");
            Console.WriteLine("0. 나가기");
            Console.Write("\n원하시는 행동을 입력해주세요.\n>> ");
            string inp = Console.ReadLine();
            if (inp == "1")
            {
                ManageEquip();
            }
            else if (inp == "0")
            {
                break;
            }
            else
            {
                Console.WriteLine("잘못된 입력입니다");
                Pause();
            }
        }
    }

    // 아이템 장착 관리 화면
    static void ManageEquip()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("장착관리");
            Console.WriteLine("[아이템 목록]");
            for (int i = 0; i < inventory.Count; i++)
            {
                string equipMark = inventory[i].Equipped ? "[E]" : "";
                Console.WriteLine($"- {i + 1}. {equipMark}{inventory[i].Name} | {inventory[i].Type} +{inventory[i].Bonus} | {inventory[i].Description}");
            }
            Console.WriteLine("\n0. 나가기");
            Console.Write("\n원하시는 행동을 입력해주세요.\n>> ");
            string inp = Console.ReadLine();
            if (inp == "0")
                break;
            int index;
            if (int.TryParse(inp, out index))
            {
                if (index >= 1 && index <= inventory.Count)
                {
                    // 이미 장착 중이면 장착 해제, 아니면 장착
                    if (inventory[index - 1].Equipped)
                        inventory[index - 1].Equipped = false;
                    else
                        inventory[index - 1].Equipped = true;
                }
                else
                {
                    Console.WriteLine("잘못된 입력입니다");
                    Pause();
                }
            }
            else
            {
                Console.WriteLine("잘못된 입력입니다");
                Pause();
            }
        }
    }

    static void DungeonExplore()
    {
        Console.Clear();
        bool isBoss = rand.Next(0, 100) < 20; 
        int monsterHP = isBoss ? 150 : 80;
        int monsterAttack = isBoss ? rand.Next(15, 26) : rand.Next(5, 16);
        Console.WriteLine(isBoss ? "보스몬스터 등장!" : "몬스터 등장!");
        Pause();

        // 전투 턴제 전투
        while (player.HP > 0 && monsterHP > 0)
        {
            Console.Clear();
            Console.WriteLine($"플레이어 HP: {player.HP}  |  몬스터 HP: {monsterHP}");
            Console.WriteLine("\n공격하시려면 1번, 필살기 사용은 2번을 입력하세요.");
            Console.Write(">> ");
            string action = Console.ReadLine();
            int damage = 0;
            if (action == "1")
            {
                damage = player.TotalAttack - rand.Next(0, 3); 
                Console.WriteLine($"{player.Name}의 공격! 몬스터에게 {damage}의 데미지!");
            }
            else if (action == "2")
            {
                if (rand.Next(0, 100) < 30)
                {
                    damage = monsterHP;
                    Console.WriteLine("필살기 발동! 몬스터를 즉사시켰습니다!");
                }
                else
                {
                    damage = player.TotalAttack * 2 - rand.Next(0, 5);
                    Console.WriteLine("필살기 공격! 몬스터에게 큰 데미지를 입혔습니다!");
                }
            }
            else
            {
                Console.WriteLine("잘못된 입력입니다, 공격 손실!");
            }
            monsterHP -= (damage > 0 ? damage : 0);
            if (monsterHP <= 0) break;
            // 몬스터 공격
            int monsterDmg = monsterAttack - player.TotalDefense / 2;
            if (monsterDmg < 0) monsterDmg = 0;
            player.HP -= monsterDmg;
            Console.WriteLine($"몬스터 공격! {player.Name}에게 {monsterDmg}의 데미지!");
            Pause();
        }
        // 전투 결과 판정
        if (player.HP > 0)
        {
            Console.WriteLine("전투 승리!");
            int reward = rand.Next(100, 501);
            Console.WriteLine($"미션 완료! 보상 골드 {reward} G 획득");
            player.Gold += reward;
        }
        else
        {
            Console.WriteLine("플레이어 HP 0, 게임오버!");
            gameOver = true;
        }
        // 전투 후 체력 회복 약간
        player.HP = (player.HP > 0 ? player.HP + 20 : 0);
        Pause();
    }

    // 길드 생성 기능 (간단 구현)
    static void CreateGuild()
    {
        Console.Clear();
        Console.Write("길드 이름을 입력하세요: ");
        string guildName = Console.ReadLine();
        Console.WriteLine($"\n길드 [{guildName}] 이(가) 스파르타 마을에 생성되었습니다.");
        Console.WriteLine("길드원: 스파르타 시민 (다수)");
        Pause();
    }

    // 엔딩 ASCII 아트와 재시작 메시지
    static void ShowEnding()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("      .-~~~~~~~~~-._       _.-~~~~~~~~~-.");
        Console.WriteLine("  __.'              ~.   .~              `.__");
        Console.WriteLine(".'//                  \\./                  \\\\`.");
        Console.WriteLine("////                    |                    \\\\\\");
        Console.WriteLine("////                     |                     \\\\\\");
        Console.WriteLine(" `--___________-._     |     _.-___________--'");
        Console.ResetColor();
        Console.WriteLine("\n엔딩 도달!");
    }

    // 입력 후 일시정지 함수
    static void Pause()
    {
        Console.WriteLine("\n계속하려면 엔터키를 누르세요.");
        Console.ReadLine();
    }
}
